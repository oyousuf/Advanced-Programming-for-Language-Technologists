import argparse
import pickle
import os

import yaml

from tagger import pre_process, model
from sklearn.metrics import classification_report


def run(args):
    mode = args.mode
    with open(args.config, "r") as yaml_in:
        config = yaml.load(yaml_in)
    if mode == "train":
        print(f"Training a model on {config['train_file']}.")
        X, Y = pre_process.load_dataset(config["train_file"])
        X, Y = pre_process.prepare_data_for_training(X, Y)
        tagger = model.POSTagger()
        tagger.fit_and_report(X, Y, config["crossval"], config["n_folds"])
        tagger.save_model(config["model_file"])
    elif mode == "tag":
        print(f"Tagging text using pretrained model: {config['model_file']}.")
        with open(config["model_file"], "rb") as model_in:
            tagger = pickle.load(model_in)
        if not os.path.isfile(args.text):
            tagged_sent = tagger.tag_sentence(args.text)
            for token in tagged_sent:
                print(f"{token[0]}\t{token[1]}".expandtabs(15))
        else:
            tagged_sents = tagger.tag_file(args.text)
            with open(args.text + '.tag', 'w') as f:
                for sent in tagged_sents:
                    for item in sent:
                        print(item[0] + '\t' + item[1], file = f)
                    print('', file = f)
    elif mode == "eval":
        gold_file = args.gold
        print(f"Evaluating tagger on: {gold_file}.")
        with open(config["model_file"], "rb") as model_in:
            tagger = pickle.load(model_in)
        sents, gold_tags = pre_process.load_dataset(gold_file)
        Y_true = [item for sublist in gold_tags for item in sublist]
        tagged_sents = [tagger.tag_sentence(sent) for sent in sents]
        Y_predicted = [item[1] for sublist in tagged_sents for item in sublist]
        print(classification_report(Y_true, Y_predicted))
                    
    else:
        print(f"{args.mode} is an incompatible mode. Must be either 'train', 'tag' or 'eval'.")


if __name__ == '__main__':
    PARSER = argparse.ArgumentParser(description="A basic SVM-based POS-tagger. \
                                     Accepts either .conllu or tab-delineated \
                                     .txt files for training.")

    PARSER.add_argument('--mode', metavar='M', type=str,
                        help="Specifies the tagger mode: {train, tag, eval}.")
    PARSER.add_argument('--text', metavar='T', type=str,
                        help="Tags a sentence string. \
                        Can only be called if '--mode tag' is specified.")
    PARSER.add_argument('--gold', metavar='G', type=str,
                        help="Tags a gold file and compares it against the gold annotations. \
                        Can only be called if '--mode eval' is specified.")
    PARSER.add_argument('--config', metavar='C', type=str,
                        help="A config .yaml file that specifies the train data, \
                        model output file, and number of folds for cross-validation.")

    ARGS = PARSER.parse_args()

    run(ARGS)
