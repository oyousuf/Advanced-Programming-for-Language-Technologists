def load_txt(file):
    X, Y = [], []
    with open(file, "r", encoding = 'utf-8') as infile:
        sents = infile.read().split("\n\n")
        if sents[-1] == "":
            sents = sents[:-1]
        for sent in sents:
            words, tags = [], []
            lines = sent.split("\n")
            for line in lines:
                line = line.strip().split("\t")
                if len(line) != 2:
                    raise TabError("Tried to read .txt file, but did not find two columns.")
                else:
                    words.append(line[0])
                    tags.append(line[1])
            X.append(words)
            Y.append(tags)

    return X, Y


def load_conllu(file):
    X, Y = [], []
    with open(file, "r", encoding = 'utf-8') as infile:
        sents = infile.read().split("\n\n")
        if sents[-1] == "":
            sents = sents[:-1]
        for sent in sents:
            words, tags = [], []
            lines = sent.split("\n")
            for line in lines:
                if line.startswith("#"):
                    continue
                line = line.strip().split("\t")
                if len(line) != 10:
                    raise TabError("Tried to read .txt file, but did not find ten columns.")
                else:
                    words.append(line[1])
                    tags.append(line[3])
            X.append(words)
            Y.append(tags)

    return X, Y


def load_dataset(file):
    if file.endswith(".conllu"):
        try:
            X, Y = load_conllu(file)
            return X, Y
        except TabError:
            print("Tried to read .txt file, but did not find ten columns.")
    else:
        try:
            X, Y = load_txt(file)
            return X, Y
        except TabError:
            print("Tried to read .txt file, but did not find two columns.")


def token_to_features(sent, i):
    word = sent[i]

    features = {
        'word.lower()': word.lower(),
        'word.len' : str(len(word)),
        'word.ind' : str(i) if i < 5 else '',
        'word[-2:]': word[-2:] if len(word) > 3 else '',
        'word[-3:]': word[-3:] if len(word) > 4 else '',
        'word[-4:]' : word[-4:] if len(word) > 5 else '',
        'word[-1]' : word[-1] if len(word) > 2 else '',
        'word.isupper()': word.isupper(),
        'word.istitle()': word.istitle(),
        'word.isdigit()': word.isdigit(),
        'word.hyphen' : '-' in word
    }
    
        
    if i > 0:
        word1 = sent[i-1]
        features.update({
            '-1:word.lower()': word1.lower(),
            '-1:word.istitle()': word1.istitle(),
            '-1:word.isupper()': word1.isupper(),
            '-1:word.isdigit()' : word1.isdigit(),
            'word[0].isupper': word[0].isupper(),
            '-1:word[-2:]' : word1[-2:] if len(word1) > 4 else '',
            '-1:word[-3:]' : word1[-3:] if len(word1) > 3 else '',
            '-1:word[-4:]' : word1[-4:] if len(word) > 5 else '',
            '-1:word[-1]' : word1[-1] if len(word) > 2 else '',
        })

    else:
        features['BOS'] = True
        
        
        
    if i < len(sent)-1:
        word2 = sent[i+1]
        features.update({
            '+1:word.lower()': word2.lower(),
            '+1:word.istitle()': word2.istitle(),
            '+1:word.isupper()': word2.isupper(),
            '+1:word.isdigit()' : word2.isdigit(),
            '+1:word[0].isupper': word2[0].isupper(), 
            '+1:word[-2:]': word2[-2:] if len(word2) > 3 else '',
            '+1:word[-3:]': word2[-3:] if len(word2) > 4 else '',
            '+1:word[-4:]' : word2[-4:] if len(word2) > 5 else '',
            '+1:word[-1]' : word2[-1] if len(word2) > 2 else '',
        })
    else:
        features['EOS'] = True
    

    if i == len(sent) - 2:
        features.update({'last_word' : True})

    return features


def prepare_data_for_training(X, Y):
    X_out, Y_out = [], []
    for i, sent in enumerate(X):
        for j, token in enumerate(sent):
            features = token_to_features(sent, j)
            X_out.append(features)
            Y_out.append(Y[i][j])

    return X_out, Y_out
