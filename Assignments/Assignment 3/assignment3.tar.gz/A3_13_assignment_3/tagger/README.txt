# Document tagging

We added a function tag_file(path) to the model.py file. First this function reads in the file and preprocesses it so that punctuation
marks are added to the end of headlines and similar lines that should be considered as separate sentences but do not end with punctuation.
The reason for that step is that neither spacy nor nltk were successful in tokenizing the example files in their original form. After preprocessing
nltk is used to divide the text into sentences (we also experimented with spacy but that gave a memory error when testing the script). Thereafter,
the original tag_sentence() function is applied to each sentence, and in the end the function returns a list of tagged sentences. The tokens and
their tags are then written to a file (this last part is implemented in the run.py file).

Tagging a document:

python run.py --mode tag --text path_to_file.txt --config config.yaml

# Evaluation

Everything relevant to the evaluation part can be found in the run.py file (except for an extra if-else
clause in the tag_sentence() function that checks whether the sentence is already in a tokenized form). 
If the eval mode is chosen by the user, they are also expected to provide the path to the gold file
they want to evaluate on. The load_dataset() function is used for obtaining the sentences and tags from
the gold file. The saved model is used to tag all sentences and thereafter predicted tags are saved in a
list. At the end, the classification_report function from sklearn is called to produce a summary of the 
results.

Running the eval script: 

python run.py --mode eval --gold path_to_gold_file.txt --config config.yaml


# Features

Compared to the original code, we have added some features to the token_to_features function in pre_process.py.
A list of added features follows here:
- Index i of the current word in case i is smaller than 5
- Length of the current word
- The last 4 characters of the current word if the word is longer than 5 characters
- The last character of the current word if the word is longer than 2 characters
- Whether the word includes a hyphen
- Whether the word starts with a capital letter (when its index is not 0)
- The features capturing the last 2 and 3 characters of the current word were kept
  but only for words longer than 3 and 4 characters respectively
- The four suffixes (with lengths 1, 2, 3 and 4) of the previous word with the 
  same conditions as for the current word
- The four suffixes (with lengths 1, 2, 3 and 4) of the next word with the
  same conditions as for the current word
- Whether the next word starts with a capital letter
- The penultimate word in a sentence got the feature 'last_word' 
  (because usually the last item is a punctuation mark)

We also experimented with different models that sklearn provides 
(sgd, decision tree, naive bayes, nearest neighbors) but that did not improve parsing accuracy, 
so the original svm was chosen in the end. The extended features did lead to a small improvement
on the UD English Web Treebank's test set where we achieved a weighted average of 0.94 (0.93 in the
assignment instructions).