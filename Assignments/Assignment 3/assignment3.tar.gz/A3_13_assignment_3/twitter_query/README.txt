A script for printing out a chosen Twitter user's N most recent tweets together with their dates.

Running the script from the command line:
>python3 twitter_query.py USERNAME (COUNT)

where:
USERNAME - the Twitter user's handle
COUNT - an optional argument specifying how many tweets to retrieve, defaults to 1


The twitter_query.py script contains a function get_tweets() that takes the username and number of tweets as
arguments and uses Tweepy to retrieve the tweets from Twitter. We have chosen not to include retweets
because these are not the user's "own" tweets. The rest is kept as retrieved from the API, meaning
there is no special treatment of emoticons, replies or images.
