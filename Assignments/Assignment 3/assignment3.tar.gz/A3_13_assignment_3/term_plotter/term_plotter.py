import json
import nltk
from nltk.corpus import stopwords  
from sklearn.feature_extraction.text import TfidfVectorizer
import os
import pandas as pd
from pandas.plotting import register_matplotlib_converters
import matplotlib.pyplot as plt
import seaborn as sns
import argparse
register_matplotlib_converters()


def plot_terms(terms, path, title, output):
    #Check if the path is correct
    try:
        files = os.listdir(path)
    except:
        print('The file path you provided is incorrect, please try again using the correct path.')
        return None
        
    speeches = []
    dates = []
    for file in files:
        with open(path+file, "r") as infile:
            speech = json.load(infile)
            speeches.append(speech['Speech'])
            dates.append(speech['Date'])
    vectorizer = TfidfVectorizer(stop_words = stopwords.words('english'), ngram_range=(1,3))
    X = vectorizer.fit_transform(speeches)
    
    #Collect all terms that do not appear in the vocabulary
    not_in_vocab = []
    for t in terms:
        try:
            vectorizer.get_feature_names().index(t.lower())
        except:
            not_in_vocab.append(t)
            
    if not not_in_vocab:
        indices_terms = [(vectorizer.get_feature_names().index(t.lower()), t.lower()) for t in terms]
    
        #Get all the scores
        dates2 = []
        scores = []
        terms_all = []
        for i in range(1016):
            for ind, term in indices_terms:
                scores.append(X[i].T.toarray()[ind][0])
                dates2.append(dates[i])
                terms_all.append(term)
        
        #Populate the dataframe
        df = pd.DataFrame()
        df['Date'] = dates2
        df['Score'] = scores
        df['Term'] = terms_all
        df['Date'] = pd.to_datetime(df['Date'])
    
        #Create the plot
        plot = sns.lineplot(
        x="Date",
        y="Score",
        hue='Term',
        data=df
        ).set_title(title)
    
        #Set output file name
        if output:
            output_title = output
        else:
            output_title = ' '.join(terms).replace(' ', '_')
    
        #Save the plot
        plot.figure.savefig(output_title + '.png')
    else:
        print('Sorry but the following terms were not used in the speeches:')
        for t in not_in_vocab:
            print(t)
        print('If you exclude these terms, it should work.')


if __name__ == "__main__":

    parser = argparse.ArgumentParser()
    parser.add_argument("terms", help="List the strings you want to create the graph for.")
    parser.add_argument("--path", help="Specify the path to the presidential speeches.")
    parser.add_argument("--title", help="Specify the graph title.")
    parser.add_argument("--output", help="Specify the name of the output file.")
    args, unknown = parser.parse_known_args()
    
    terms = [args.terms] + unknown
 
    if args.path:
        path = args.path
    else:
        path ="./us_presidential_speeches/"
    plot_terms(terms,path, args.title, args.output)
    