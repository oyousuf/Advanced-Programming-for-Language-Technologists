The term plotter accepts up to 5 terms as arguments and creates a plot based on the speeches of US presidents
with the year of the speech on the x-axis and the term's tf-idf score on the y-axis. 

Using the term_plotter (note that terms is a positional argument, meaning --terms should NOT be included when calling the script):

python term_plotter.py "america" "united states" 

In addition, there are 3 optional arguments that can be added:

--path "path_to_the_speeches"

--title "this_is_the_plot_title"

--output "name_of_saved_plot"

The term plotter uses a function plot_terms that first checks whether the file path is correct. Thereafter
speeches are collected and TfIdfVectorizer is used. The function checks whether all terms are present in the
vectorizer's vocabulary. If not, the user is asked to eliminate those before trying again. If all terms
are present, the function loops through all speeches to get the date and score for each term. That information
is then used to create the plot.