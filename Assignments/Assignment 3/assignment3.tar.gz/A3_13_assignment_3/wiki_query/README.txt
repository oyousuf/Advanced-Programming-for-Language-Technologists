In this script, wiki_query.py, we've defined a function, "get_wikipedia_content", that allows the user to pass through a string entry from 
the command line to search for the corresponding wikipedia entry. The function then returns the full (relevant) text to the user. 
Revelant meaning main chunks of texts categorized as paragraphs by the website/HTML code.

*** Note: If you choose to analyze our code please take heed of the following bits:
 - the last line in our try statement is to overcome the all too common 'See Also' component in numerous wikipedia entries.

 - The lone for-loop is to overcome random pieces of text that preceededd our main paragraphs (i.e., coordinates).

 - Finally, the last if statement is to ensure the user doesn't use the help arguments in the second parameter which is crucially passed in.